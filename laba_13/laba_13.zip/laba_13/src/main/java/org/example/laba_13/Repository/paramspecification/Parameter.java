package org.example.laba_13.Repository.paramspecification;

import java.util.List;

public interface Parameter {
    List<Object> getParameters();
}
