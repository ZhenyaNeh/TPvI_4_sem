USE master
GO
xp_readerrorlog 0, 1, N'Server is listening on'
GO