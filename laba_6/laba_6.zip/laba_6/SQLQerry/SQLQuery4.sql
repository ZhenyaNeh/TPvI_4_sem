USE [LIBRARY]

CREATE LOGIN myuser WITH PASSWORD= N'myuser'

CREATE user myuser for login myuser
